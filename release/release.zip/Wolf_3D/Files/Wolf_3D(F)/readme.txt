In order to run the full version of the game, you need to place the 
wolf3d game data files here.

